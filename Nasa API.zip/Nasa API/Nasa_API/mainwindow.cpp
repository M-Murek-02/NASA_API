#include "mainwindow.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonObject>
#include <QPixmap>
#include <QUrl>
#include <QPushButton>
#include <QIcon>
#include <QFile>
#include <QTextStream>
#include <QListWidget>
#include <QMessageBox>

// Ścieżka do pliku z listą ulubionych zdjęć
static const QString FAVORITES_FILE = "Ulubione.txt";

// Konstruktor głównego okna aplikacji
MainWindow::MainWindow(QWidget *parent)
    : QWidget(parent),
      networkManager(new QNetworkAccessManager(this)), // Menedżer do obsługi żądań sieciowych
      calendarDialog(nullptr)
{
    // Ustawienie tytułu programu
    setWindowTitle("NASA APOD - Zdjęcie dnia");

    // Główny layout pionowy
    auto *layout = new QVBoxLayout(this);

    // Przyciski akcji użytkownika
    fetchButton = new QPushButton("Pobierz zdjęcie dzisiaj", this);
    calendarButton = new QPushButton("Kalendarz", this);
    favoritesButton = new QPushButton("Ulubione", this);
    layout->addWidget(fetchButton);
    layout->addWidget(calendarButton);
    layout->addWidget(favoritesButton);

    // Layout dla tytułu i przycisku gwiazdki (ulubione)
    auto *titleLayout = new QHBoxLayout;
    titleLabel = new QLabel("Tytuł: ", this);
    starButton = new QPushButton("★", this); // Gwiazdka oznaczająca ulubione
    starButton->setToolTip("Dodaj do ulubionych");
    starButton->setFixedWidth(30);
    updateStarIcon();
    titleLayout->addWidget(titleLabel);
    titleLayout->addWidget(starButton);
    titleLayout->addStretch();
    layout->addLayout(titleLayout);

    // Etykiety i pole tekstowe na opis
    dateLabel  = new QLabel("Data:  ", this);
    imageLabel = new QLabel(this);
    explanationText = new QTextEdit(this);
    explanationText->setReadOnly(true);

    layout->addWidget(dateLabel);
    layout->addWidget(imageLabel);
    layout->addWidget(explanationText);

    // Przycisk zamknięcia aplikacji
    closeButton = new QPushButton("Zamknij program", this);
    layout->addWidget(closeButton);

    // Połączenie sygnałów z funkcjami obsługującymi
    connect(fetchButton, &QPushButton::clicked, this, &MainWindow::fetchAPOD);
    connect(calendarButton, &QPushButton::clicked, this, &MainWindow::onCalendarClicked);
    connect(favoritesButton, &QPushButton::clicked, this, &MainWindow::onShowFavoritesClicked);
    connect(closeButton, &QPushButton::clicked, this, &MainWindow::onCloseClicked);
    connect(starButton, &QPushButton::clicked, this, &MainWindow::onFavoriteClicked);
}

MainWindow::~MainWindow() = default;

// Aktualizacja wyglądu gwiazdki (ulubione)
void MainWindow::updateStarIcon() {
    if (isFavorite)
        starButton->setStyleSheet("color: yellow; font-size:18px;");
    else
        starButton->setStyleSheet("color: black; font-size:18px;");
}

// Funkcja pobierająca dane z NASA APOD dla dzisiejszej daty
void MainWindow::fetchAPOD() {
    const QUrl apiUrl("https://api.nasa.gov/planetary/apod?api_key=pgVapEJvh7hxNyeDSK1lCRVoOb6VIhx5AH4c9AtM"); // Użycie klucza API
    QNetworkRequest request(apiUrl); // Tworzenie żądania HTTP GET
    QNetworkReply *reply = networkManager->get(request); // Wysłanie żądania

    // Obsługa odpowiedzi po zakończeniu pobierania JSON-a
    connect(reply, &QNetworkReply::finished, this, [this, reply]() {
        const auto json = QJsonDocument::fromJson(reply->readAll()).object(); // Parsowanie odpowiedzi JSON
        currentTitle = json.value("title").toString();        // Tytuł zdjęcia
        currentDate = json.value("date").toString();          // Data zdjęcia
        QString explanation = json.value("explanation").toString(); // Opis zdjęcia
        const QUrl imageUrl = QUrl(json.value("url").toString());   // Adres URL do obrazka

        // Aktualizacja widżetów GUI
        titleLabel->setText("Tytuł: " + currentTitle);
        dateLabel->setText("Data:  " + currentDate);
        explanationText->setPlainText(explanation);
        imageLabel->clear();

        // Sprawdzenie, czy zdjęcie jest już w ulubionych
        isFavorite = loadFavorites().contains(currentDate + " - " + currentTitle);
        updateStarIcon();

        // Pobieranie obrazka z podanego URL
        QNetworkReply *imgReply = networkManager->get(QNetworkRequest(imageUrl));
        connect(imgReply, &QNetworkReply::finished, this, [this, imgReply]() {
            QPixmap pix;
            pix.loadFromData(imgReply->readAll()); // Wczytanie obrazu z bajtów
            imageLabel->setPixmap(pix.scaled(
                500, 400, Qt::KeepAspectRatio, Qt::SmoothTransformation)); // Dopasowanie do okna
            imgReply->deleteLater();
        });

        reply->deleteLater(); // Zwolnienie pamięci po zakończeniu żądania
    });
}

// Wyświetlenie kalendarza do wyboru daty
void MainWindow::onCalendarClicked() {
    if (calendarDialog) delete calendarDialog;

    calendarDialog = new QDialog(this);
    calendarDialog->setWindowTitle("Wybierz datę APOD");
    auto *dlgLayout = new QVBoxLayout(calendarDialog);
    calendarWidget = new QCalendarWidget(calendarDialog);
    calendarWidget->setMinimumDate(QDate(2000, 1, 1)); // Minimalna data zdjęć
    calendarWidget->setMaximumDate(QDate::currentDate());
    calendarWidget->setSelectedDate(QDate::currentDate());
    dlgLayout->addWidget(calendarWidget);
    connect(calendarWidget, &QCalendarWidget::activated,
            this, &MainWindow::onDateSelected);

    calendarDialog->setLayout(dlgLayout);
    calendarDialog->resize(400, 300);
    calendarDialog->exec();
}

// Obsługa wyboru daty z kalendarza – wykonanie zapytania API dla konkretnej daty
void MainWindow::onDateSelected(const QDate &date) {
    if (calendarDialog) calendarDialog->accept();
    currentDate = date.toString("yyyy-MM-dd");

    // Budowa URL z parametrem ?date=YYYY-MM-DD
    QNetworkRequest request(
        QUrl(QString("https://api.nasa.gov/planetary/apod?api_key=pgVapEJvh7hxNyeDSK1lCRVoOb6VIhx5AH4c9AtM&date=%1").arg(currentDate))
    );
    QNetworkReply *reply = networkManager->get(request);

    // Obsługa odpowiedzi
    connect(reply, &QNetworkReply::finished, this, [this, reply]() {
        const auto json = QJsonDocument::fromJson(reply->readAll()).object();
        currentTitle = json.value("title").toString();
        QString explanation = json.value("explanation").toString();
        const QUrl imageUrl = QUrl(json.value("url").toString());

        titleLabel->setText("Tytuł: " + currentTitle);
        dateLabel->setText("Data:  " + currentDate);
        explanationText->setPlainText(explanation);
        imageLabel->clear();

        isFavorite = loadFavorites().contains(currentDate + " - " + currentTitle);
        updateStarIcon();

        QNetworkReply *imgReply = networkManager->get(QNetworkRequest(imageUrl));
        connect(imgReply, &QNetworkReply::finished, this, [this, imgReply]() {
            QPixmap pix;
            pix.loadFromData(imgReply->readAll());
            imageLabel->setPixmap(pix.scaled(
                500, 400, Qt::KeepAspectRatio, Qt::SmoothTransformation));
            imgReply->deleteLater();
        });

        reply->deleteLater();
    });
}

// Obsługa kliknięcia gwiazdki – dodanie lub usunięcie z ulubionych
void MainWindow::onFavoriteClicked() {
    const QString favEntry = currentDate + " - " + currentTitle;
    if (!isFavorite) {
        saveFavorite(currentDate, currentTitle);
        isFavorite = true;
    } else {
        removeFavorite(currentDate, currentTitle);
        isFavorite = false;
    }
    updateStarIcon();
}

// Zapisanie pozycji do pliku ulubionych
void MainWindow::saveFavorite(const QString &date, const QString &title) {
    QFile file(FAVORITES_FILE);
    if (file.open(QIODevice::Append | QIODevice::Text)) {
        QTextStream out(&file);
        out << date << " - " << title << "\n";
        file.close();
    }
}

// Usunięcie pozycji z pliku ulubionych
void MainWindow::removeFavorite(const QString &date, const QString &title) {
    const QString entry = date + " - " + title;
    QFile file(FAVORITES_FILE);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) return;
    QStringList lines;
    QTextStream in(&file);
    while (!in.atEnd()) lines << in.readLine();
    file.close();
    lines.removeAll(entry);
    if (file.open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text)) {
        QTextStream out(&file);
        for (const QString &l : lines) out << l << "\n";
        file.close();
    }
}

// Wczytanie listy ulubionych z pliku
QStringList MainWindow::loadFavorites() const {
    QStringList list;
    QFile file(FAVORITES_FILE);
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        while (!in.atEnd()) list << in.readLine();
        file.close();
    }
    return list;
}

// Wyświetlenie okna dialogowego z listą ulubionych zdjęć
void MainWindow::onShowFavoritesClicked() {
    QDialog dlg(this);
    dlg.setWindowTitle("Ulubione");
    QVBoxLayout *vLayout = new QVBoxLayout(&dlg);
    QListWidget *listWidget = new QListWidget(&dlg);
    listWidget->addItems(loadFavorites());
    connect(listWidget, &QListWidget::itemDoubleClicked,
            this, &MainWindow::onFavoriteItemDoubleClicked);
    vLayout->addWidget(listWidget);
    QPushButton *closeFav = new QPushButton("Zamknij", &dlg);
    connect(closeFav, &QPushButton::clicked, &dlg, &QDialog::accept);
    vLayout->addWidget(closeFav);
    dlg.exec();
}

// Obsługa kliknięcia dwukrotnego na ulubiony wpis – automatyczne załadowanie danych z wybranej daty
void MainWindow::onFavoriteItemDoubleClicked(QListWidgetItem *item) {
    const QString entry = item->text();
    const QString date = entry.section(' ', 0, 0);
    onDateSelected(QDate::fromString(date, "yyyy-MM-dd"));
}

// Zamknięcie programu
void MainWindow::onCloseClicked() {
    close();
}
