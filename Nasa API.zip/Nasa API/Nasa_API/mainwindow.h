#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QWidget>
#include <QLabel>
#include <QTextEdit>
#include <QNetworkAccessManager>
#include <QDate>
#include <QPushButton>
#include <QCalendarWidget>
#include <QDialog>
#include <QStringList>

class QNetworkReply;
class QListWidget;
class QListWidgetItem;

class MainWindow : public QWidget {
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

private slots:
    void fetchAPOD();
    void onCalendarClicked();
    void onDateSelected(const QDate &date);
    void onCloseClicked();
    void onFavoriteClicked();
    void onShowFavoritesClicked();
    void onFavoriteItemDoubleClicked(QListWidgetItem *item);

private:
    void saveFavorite(const QString &date, const QString &title);
    void removeFavorite(const QString &date, const QString &title);
    QStringList loadFavorites() const;
    void updateStarIcon();

    QNetworkAccessManager *networkManager;
    QLabel  *titleLabel;
    QLabel  *dateLabel;
    QLabel  *imageLabel;
    QTextEdit *explanationText;
    QPushButton *fetchButton;
    QPushButton *calendarButton;
    QPushButton *closeButton;
    QPushButton *starButton;
    QPushButton *favoritesButton;
    QDialog *calendarDialog;
    QCalendarWidget *calendarWidget;

    QString currentDate;
    QString currentTitle;
    bool isFavorite = false;
};

#endif // MAINWINDOW_H
