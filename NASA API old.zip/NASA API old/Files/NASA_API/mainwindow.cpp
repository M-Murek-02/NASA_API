// W Twoim mainwindow.cpp
#include "mainwindow.h"
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QPixmap>
#include <QUrl>
#include <QDebug>
#include <qboxlayout.h>
#include <qlabel.h>

// Zakładam, że masz:
QNetworkAccessManager *networkManager; // Zmienna w MainWindow
QPixmap originalImage;                 // Też w MainWindow
QLabel *imageLabel;                     // Twój QLabel do obrazka

// Przykładowa funkcja:
void MainWindow::fetchAPOD()
{
    QString apiKey = "DEMO_KEY"; // Lub Twój własny klucz
    QString apiUrl = "https://api.nasa.gov/planetary/apod?api_key=" + apiKey;

    QNetworkRequest request((QUrl(apiUrl)));
    QNetworkReply *reply = networkManager->get(request);

    connect(reply, &QNetworkReply::finished, [this, reply]() {
        if (reply->error() != QNetworkReply::NoError) {
            qDebug() << "Błąd pobierania APOD:" << reply->errorString();
            reply->deleteLater();
            return;
        }

        QByteArray responseData = reply->readAll();
        QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);
        QJsonObject jsonObj = jsonDoc.object();

        QString title = jsonObj["title"].toString();
        QString date = jsonObj["date"].toString();
        QString explanation = jsonObj["explanation"].toString();
        QString mediaType = jsonObj["media_type"].toString();
        QString imageUrl = jsonObj["url"].toString();

        // Wyświetl teksty (jeśli masz odpowiednie QLabel/QTextEdit)
        titleLabel->setText("Tytuł: " + title);
        dateLabel->setText("Data: " + date);
        explanationText->setText(explanation);

        // Jeśli to obraz, pobieramy
        if (mediaType == "image" && !imageUrl.isEmpty()) {
            QNetworkRequest imgRequest((QUrl(imageUrl)));
            QNetworkReply *imgReply = networkManager->get(imgRequest);

            connect(imgReply, &QNetworkReply::finished, [this, imgReply]() {
                if (imgReply->error() == QNetworkReply::NoError) {
                    QByteArray imgData = imgReply->readAll();
                    if (originalImage.loadFromData(imgData)) {
                        imageLabel->setPixmap(originalImage.scaled(
                            imageLabel->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));
                    } else {
                        qDebug() << "Nie udało się załadować obrazu z danych!";
                    }
                } else {
                    qDebug() << "Błąd pobierania obrazu:" << imgReply->errorString();
                }
                imgReply->deleteLater();
            });
        } else {
            qDebug() << "Dzisiejszy APOD nie jest obrazkiem.";
        }

        reply->deleteLater();
    });
}

static const QString FAVORITES_FILE = "Ulubione.txt";

MainWindow::MainWindow(QWidget *parent)
    : QWidget(parent),
    networkManager(new QNetworkAccessManager(this))
{
    networkManager = new QNetworkAccessManager(this);

    // Tworzenie widgetów
    titleLabel = new QLabel("Tytuł: ", this);
    dateLabel = new QLabel("Data: ", this);
    imageLabel = new ClickableLabel(this);
    explanationText = new QTextEdit(this);
    fetchButton = new QPushButton("Pobierz dzisiejsze APOD", this);
    calendarButton = new QPushButton("Wybierz datę", this);
    closeButton = new QPushButton("Zamknij", this);
    starButton = new QPushButton(this);
    favoritesButton = new QPushButton("Ulubione", this);

    // Ustawienia
    explanationText->setReadOnly(true);
    imageLabel->setAlignment(Qt::AlignCenter);
    imageLabel->setMinimumSize(400, 300);

    // Layout
    auto *mainLayout = new QVBoxLayout(this);
    auto *buttonLayout = new QHBoxLayout();

    buttonLayout->addWidget(fetchButton);
    buttonLayout->addWidget(calendarButton);
    buttonLayout->addWidget(starButton);
    buttonLayout->addWidget(favoritesButton);
    buttonLayout->addWidget(closeButton);

    mainLayout->addWidget(titleLabel);
    mainLayout->addWidget(dateLabel);
    mainLayout->addWidget(imageLabel, 1); // ważne: stretch = 1, żeby rosnął
    mainLayout->addWidget(explanationText);
    mainLayout->addLayout(buttonLayout);

    setLayout(mainLayout);

    // Połączenia sygnałów i slotów
    connect(fetchButton, &QPushButton::clicked, this, &MainWindow::fetchAPOD);
    connect(calendarButton, &QPushButton::clicked, this, &MainWindow::onCalendarClicked);
    connect(closeButton, &QPushButton::clicked, this, &MainWindow::onCloseClicked);
    connect(starButton, &QPushButton::clicked, this, &MainWindow::onFavoriteClicked);
    connect(favoritesButton, &QPushButton::clicked, this, &MainWindow::onShowFavoritesClicked);
    connect(imageLabel, &ClickableLabel::clicked, this, &MainWindow::onImageClicked);

    updateStarIcon();
}

MainWindow::~MainWindow() = default;

void MainWindow::updateStarIcon() {
    if (isFavorite) {
        starButton->setText("★");
    } else {
        starButton->setText("☆");
    }
}



void MainWindow::onCalendarClicked() {
    if (calendarDialog) delete calendarDialog;

    calendarDialog = new QDialog(this);
    calendarDialog->setWindowTitle("Wybierz datę APOD");
    auto *dlgLayout = new QVBoxLayout(calendarDialog);
    calendarWidget = new QCalendarWidget(calendarDialog);
    calendarWidget->setMinimumDate(QDate(1995, 6, 16));
    calendarWidget->setMaximumDate(QDate::currentDate());
    calendarWidget->setSelectedDate(QDate::currentDate());
    dlgLayout->addWidget(calendarWidget);
    connect(calendarWidget, &QCalendarWidget::activated,
            this, &MainWindow::onDateSelected);

    calendarDialog->setLayout(dlgLayout);
    calendarDialog->resize(400, 300);
    calendarDialog->exec();
}

void MainWindow::onDateSelected(const QDate &date) {
    if (calendarDialog) calendarDialog->accept();
    currentDate = date.toString("yyyy-MM-dd");
    QNetworkRequest request(
        QUrl(QString("https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY&date=%1").arg(currentDate))
        );
    QNetworkReply *reply = networkManager->get(request);

    connect(reply, &QNetworkReply::finished, this, [this, reply]() {
        const auto json = QJsonDocument::fromJson(reply->readAll()).object();
        currentTitle = json.value("title").toString();
        QString explanation = json.value("explanation").toString();
        const QUrl imageUrl = QUrl(json.value("url").toString());

        titleLabel->setText("Tytuł: " + currentTitle);
        dateLabel->setText("Data: " + currentDate);
        explanationText->setPlainText(explanation);

        isFavorite = loadFavorites().contains(currentDate + " - " + currentTitle);
        updateStarIcon();

        QNetworkReply *imgReply = networkManager->get(QNetworkRequest(imageUrl));
        connect(imgReply, &QNetworkReply::finished, this, [this, imgReply]() {
            originalImage.loadFromData(imgReply->readAll());
            updateImage();
            imgReply->deleteLater();
        });

        reply->deleteLater();
    });
}

void MainWindow::onFavoriteClicked() {
    const QString favEntry = currentDate + " - " + currentTitle;
    if (!isFavorite) {
        saveFavorite(currentDate, currentTitle);
        isFavorite = true;
    } else {
        removeFavorite(currentDate, currentTitle);
        isFavorite = false;
    }
    updateStarIcon();
}

void MainWindow::saveFavorite(const QString &date, const QString &title) {
    QFile file(FAVORITES_FILE);
    if (file.open(QIODevice::Append | QIODevice::Text)) {
        QTextStream out(&file);
        out << date << " - " << title << "\n";
        file.close();
    }
}

void MainWindow::removeFavorite(const QString &date, const QString &title) {
    const QString entry = date + " - " + title;
    QFile file(FAVORITES_FILE);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) return;
    QStringList lines;
    QTextStream in(&file);
    while (!in.atEnd()) lines << in.readLine();
    file.close();
    lines.removeAll(entry);
    if (file.open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text)) {
        QTextStream out(&file);
        for (const QString &l : lines) out << l << "\n";
        file.close();
    }
}

QStringList MainWindow::loadFavorites() const {
    QStringList list;
    QFile file(FAVORITES_FILE);
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        while (!in.atEnd()) list << in.readLine();
        file.close();
    }
    return list;
}

void MainWindow::onShowFavoritesClicked() {
    QDialog dlg(this);
    dlg.setWindowTitle("Ulubione");
    QVBoxLayout *vLayout = new QVBoxLayout(&dlg);
    QListWidget *listWidget = new QListWidget(&dlg);
    listWidget->addItems(loadFavorites());
    connect(listWidget, &QListWidget::itemDoubleClicked,
            this, &MainWindow::onFavoriteItemDoubleClicked);
    vLayout->addWidget(listWidget);
    QPushButton *closeFav = new QPushButton("Zamknij", &dlg);
    connect(closeFav, &QPushButton::clicked, &dlg, &QDialog::accept);
    vLayout->addWidget(closeFav);
    dlg.exec();
}

void MainWindow::onFavoriteItemDoubleClicked(QListWidgetItem *item) {
    const QString entry = item->text();
    const QString date = entry.section(' ', 0, 0);
    onDateSelected(QDate::fromString(date, "yyyy-MM-dd"));
}

void MainWindow::onImageClicked() {
    updateImage();
}

void MainWindow::updateImage() {
    if (!originalPixmap.isNull()) {
        imageLabel->setPixmap(originalPixmap.scaled(
            imageLabel->size(),
            Qt::KeepAspectRatio,
            Qt::SmoothTransformation
            ));
    }
}

void MainWindow::onCloseClicked() {
    close();
}
