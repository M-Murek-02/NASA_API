﻿#include <QApplication>
#include <QPushButton>
#include <QVBoxLayout>
#include <QLabel>
#include <QPixmap>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonObject>
#include <QTextEdit>
#include <QBuffer>

class MainWindow : public QWidget {
    Q_OBJECT

public:
    MainWindow() {
        setWindowTitle("NASA APOD - Zdjęcie dnia");

        QVBoxLayout* layout = new QVBoxLayout(this);
        QPushButton* fetchButton = new QPushButton("Pobierz zdjęcie dnia");
        layout->addWidget(fetchButton);

        titleLabel = new QLabel("Tytuł: ");
        dateLabel = new QLabel("Data: ");
        imageLabel = new QLabel;
        explanationText = new QTextEdit;
        explanationText->setReadOnly(true);

        layout->addWidget(titleLabel);
        layout->addWidget(dateLabel);
        layout->addWidget(imageLabel);
        layout->addWidget(explanationText);

        connect(fetchButton, &QPushButton::clicked, this, &MainWindow::fetchAPOD);

        networkManager = new QNetworkAccessManager(this);
    }

private slots:
    void fetchAPOD() {
        QUrl url("https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY");
        QNetworkRequest request(url);
        QNetworkReply* reply = networkManager->get(request);
        connect(reply, &QNetworkReply::finished, this, [=]() {
            QByteArray response = reply->readAll();
            QJsonDocument doc = QJsonDocument::fromJson(response);
            QJsonObject obj = doc.object();

            QString title = obj["title"].toString();
            QString date = obj["date"].toString();
            QString explanation = obj["explanation"].toString();
            QString imageUrl = obj["url"].toString();

            titleLabel->setText("Tytuł: " + title);
            dateLabel->setText("Data: " + date);
            explanationText->setText(explanation);

            // Pobierz obraz
            QNetworkRequest imageRequest(QUrl(imageUrl));
            QNetworkReply* imageReply = networkManager->get(imageRequest);
            connect(imageReply, &QNetworkReply::finished, this, [=]() {
                QPixmap pix;
                pix.loadFromData(imageReply->readAll());
                imageLabel->setPixmap(pix.scaled(500, 400, Qt::KeepAspectRatio));
                imageReply->deleteLater();
                });

            reply->deleteLater();
            });
    }

private:
    QNetworkAccessManager* networkManager;
    QLabel* titleLabel;
    QLabel* dateLabel;
    QLabel* imageLabel;
    QTextEdit* explanationText;
};

#include "main.moc"

int main(int argc, char* argv[]) {
    QApplication app(argc, argv);
    MainWindow window;
    window.resize(600, 800);
    window.show();
    return app.exec();
}
