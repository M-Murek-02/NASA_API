// main.cpp

// Główna biblioteka aplikacji Qt (zapewnia obsługę zdarzeń, GUI, itp.)
#include <QApplication>

// Dołączenie pliku nagłówkowego z deklaracją klasy MainWindow
#include "mainwindow.h"

// Funkcja główna programu - punkt wejścia do aplikacji
int main(int argc, char *argv[]) {
    // Tworzenie obiektu aplikacji Qt
    // `argc` i `argv` przekazują parametry linii komend do aplikacji
    QApplication app(argc, argv);

    // Tworzenie głównego okna aplikacji (MainWindow)
    MainWindow window;

    // Ustawienie domyślnego rozmiaru głównego okna (szerokość: 600px, wysokość: 600px)
    window.resize(600, 600);

    // Wyświetlenie głównego okna użytkownikowi
    window.show();

    // Uruchomienie głównej pętli zdarzeń Qt — aplikacja będzie działać, dopóki użytkownik jej nie zamknie (np. klikając "Zamknij")
    return app.exec();
}
