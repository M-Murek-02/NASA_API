#include "mainwindow.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonObject>
#include <QPixmap>
#include <QUrl>
#include <QPushButton>
#include <QIcon>
#include <QFile>
#include <QTextStream>
#include <QListWidget>
#include <QMessageBox>

// Plik, w którym zapisywane są ulubione zdjęcia
static const QString FAVORITES_FILE = "Ulubione.txt";

// Konstruktor klasy MainWindow
MainWindow::MainWindow(QWidget *parent)
    : QWidget(parent),
    networkManager(new QNetworkAccessManager(this)),
    calendarDialog(nullptr)
{
    // Ustaw ikonę okna programu
    setWindowIcon(QIcon("logo.ico"));
    setWindowTitle("NASA APOD - Zdjęcie dnia");

    // Główny układ pionowy
    auto *layout = new QVBoxLayout(this);

    // Inicjalizacja głównych przycisków
    fetchButton = new QPushButton("Pobierz zdjęcie dzisiaj", this);
    calendarButton = new QPushButton("Kalendarz", this);
    favoritesButton = new QPushButton("Ulubione", this);
    layout->addWidget(fetchButton);
    layout->addWidget(calendarButton);
    layout->addWidget(favoritesButton);

    // Etykieta tytułu + przycisk gwiazdki (ulubione)
    auto *titleLayout = new QHBoxLayout;
    titleLabel = new QLabel("Tytuł: ", this);
    starButton = new QPushButton("★", this);
    starButton->setToolTip("Dodaj do ulubionych");
    starButton->setFixedWidth(30); // szerokość przycisku
    updateStarIcon(); // aktualizacja wyglądu gwiazdki
    titleLayout->addWidget(titleLabel);
    titleLayout->addWidget(starButton);
    titleLayout->addStretch(); // rozciągacz po prawej
    layout->addLayout(titleLayout);

    // Pozostałe elementy interfejsu
    dateLabel  = new QLabel("Data:  ", this);
    imageLabel = new QLabel(this);
    explanationText = new QTextEdit(this);
    explanationText->setReadOnly(true); // pole tylko do odczytu

    layout->addWidget(dateLabel);

    // Obrazek wycentrowany poziomo
    QHBoxLayout *imageLayout = new QHBoxLayout;
    imageLayout->addStretch(); // rozciągacz z lewej
    imageLayout->addWidget(imageLabel, 0, Qt::AlignCenter);
    imageLayout->addStretch(); // rozciągacz z prawej
    layout->addLayout(imageLayout); // dodanie layoutu z obrazem

    layout->addWidget(explanationText);

    // Przycisk zamknięcia aplikacji
    closeButton = new QPushButton("Zamknij program", this);
    layout->addWidget(closeButton);

    // Połączenia sygnałów z odpowiednimi slotami
    connect(fetchButton, &QPushButton::clicked,
            this, &MainWindow::fetchAPOD);
    connect(calendarButton, &QPushButton::clicked,
            this, &MainWindow::onCalendarClicked);
    connect(favoritesButton, &QPushButton::clicked,
            this, &MainWindow::onShowFavoritesClicked);
    connect(closeButton, &QPushButton::clicked,
            this, &MainWindow::onCloseClicked);
    connect(starButton, &QPushButton::clicked,
            this, &MainWindow::onFavoriteClicked);

    // Stylizacja całej aplikacji przy pomocy CSS
    setStyleSheet(R"(

    QWidget {
        background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                    stop:0 #1e3c72, stop:1 #2a5298);
        color: grey;
        font-family: 'Segoe UI';
        font-weight: 800;
    }
    QPushButton {
        background-color: #3366cc;
        border: none;
        border-radius: 5px;
        padding: 3px 3px;
        color: white;
    }
    QPushButton:hover {
        background-color: #5588dd;
    }
    QLabel {
        font-size: 14px;
    }
    QTextEdit {
        background-color: #f0f0f0;
        color: #000;
        border-radius: 5px;
        padding: 6px;
    }
)");
}

// Destruktor
MainWindow::~MainWindow() = default;

// Aktualizacja ikony gwiazdki w zależności od tego, czy zdjęcie jest ulubione
void MainWindow::updateStarIcon() {
    if (isFavorite)
        starButton->setStyleSheet("color: yellow; font-size:18px;");
    else
        starButton->setStyleSheet("color: black; font-size:18px;");
}

// Pobiera dzisiejsze zdjęcie APOD z API NASA
void MainWindow::fetchAPOD() {
    const QUrl apiUrl("https://api.nasa.gov/planetary/apod?api_key=pgVapEJvh7hxNyeDSK1lCRVoOb6VIhx5AH4c9AtM");
    QNetworkRequest request(apiUrl);
    QNetworkReply *reply = networkManager->get(request);

    connect(reply, &QNetworkReply::finished, this, [this, reply]() {
        // Parsowanie JSON-a
        const auto json = QJsonDocument::fromJson(reply->readAll()).object();
        currentTitle = json.value("title").toString();
        currentDate = json.value("date").toString();
        QString explanation = json.value("explanation").toString();
        const QUrl imageUrl = QUrl(json.value("url").toString());

        // Wyświetlenie danych
        titleLabel->setText("Tytuł: " + currentTitle);
        dateLabel->setText("Data:  " + currentDate);
        explanationText->setPlainText(explanation);
        imageLabel->clear();

        // Sprawdzenie, czy zdjęcie jest ulubione
        isFavorite = loadFavorites().contains(currentDate + " - " + currentTitle);
        updateStarIcon();

        // Pobieranie obrazu
        QNetworkReply *imgReply = networkManager->get(QNetworkRequest(imageUrl));
        connect(imgReply, &QNetworkReply::finished, this, [this, imgReply]() {
            QPixmap pix;
            pix.loadFromData(imgReply->readAll());
            imageLabel->setPixmap(pix.scaled(
                500, 400, Qt::KeepAspectRatio, Qt::SmoothTransformation));
            imgReply->deleteLater();
        });

        reply->deleteLater();
    });
}

// Obsługa kliknięcia w przycisk "Kalendarz"
void MainWindow::onCalendarClicked() {
    if (calendarDialog) delete calendarDialog;

    // Tworzenie nowego dialogu z kalendarzem
    calendarDialog = new QDialog(this);
    calendarDialog->setWindowTitle("Wybierz datę APOD");
    auto *dlgLayout = new QVBoxLayout(calendarDialog);
    calendarWidget = new QCalendarWidget(calendarDialog);
    calendarWidget->setMinimumDate(QDate(2000, 1, 1));
    calendarWidget->setMaximumDate(QDate::currentDate());
    calendarWidget->setSelectedDate(QDate::currentDate());
    dlgLayout->addWidget(calendarWidget);
    connect(calendarWidget, &QCalendarWidget::activated,
            this, &MainWindow::onDateSelected);

    calendarDialog->setLayout(dlgLayout);
    calendarDialog->resize(400, 300);
    calendarDialog->exec(); // wyświetlenie modalu
}

// Pobranie danych dla wybranej daty
void MainWindow::onDateSelected(const QDate &date) {
    if (calendarDialog) calendarDialog->accept();
    currentDate = date.toString("yyyy-MM-dd");

    // Budowanie URL-a z datą
    QNetworkRequest request(
        QUrl(QString("https://api.nasa.gov/planetary/apod?api_key=pgVapEJvh7hxNyeDSK1lCRVoOb6VIhx5AH4c9AtM&date=%1").arg(currentDate))
        );
    QNetworkReply *reply = networkManager->get(request);

    connect(reply, &QNetworkReply::finished, this, [this, reply]() {
        const auto json = QJsonDocument::fromJson(reply->readAll()).object();
        currentTitle = json.value("title").toString();
        QString explanation = json.value("explanation").toString();
        const QUrl imageUrl = QUrl(json.value("url").toString());

        titleLabel->setText("Tytuł: " + currentTitle);
        dateLabel->setText("Data:  " + currentDate);
        explanationText->setPlainText(explanation);
        imageLabel->clear();

        isFavorite = loadFavorites().contains(currentDate + " - " + currentTitle);
        updateStarIcon();

        QNetworkReply *imgReply = networkManager->get(QNetworkRequest(imageUrl));
        connect(imgReply, &QNetworkReply::finished, this, [this, imgReply]() {
            QPixmap pix;
            pix.loadFromData(imgReply->readAll());
            imageLabel->setPixmap(pix.scaled(
                500, 400, Qt::KeepAspectRatio, Qt::SmoothTransformation));
            imgReply->deleteLater();
        });

        reply->deleteLater();
    });
}

// Obsługa kliknięcia gwiazdki – dodaj/usuń z ulubionych
void MainWindow::onFavoriteClicked() {
    const QString favEntry = currentDate + " - " + currentTitle;
    if (!isFavorite) {
        saveFavorite(currentDate, currentTitle);
        isFavorite = true;
    } else {
        removeFavorite(currentDate, currentTitle);
        isFavorite = false;
    }
    updateStarIcon();
}

// Zapisanie ulubionego zdjęcia do pliku
void MainWindow::saveFavorite(const QString &date, const QString &title) {
    QFile file(FAVORITES_FILE);
    if (file.open(QIODevice::Append | QIODevice::Text)) {
        QTextStream out(&file);
        out << date << " - " << title << "\n";
        file.close();
    }
}

// Usunięcie zdjęcia z ulubionych
void MainWindow::removeFavorite(const QString &date, const QString &title) {
    const QString entry = date + " - " + title;
    QFile file(FAVORITES_FILE);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) return;
    QStringList lines;
    QTextStream in(&file);
    while (!in.atEnd()) lines << in.readLine();
    file.close();
    lines.removeAll(entry);
    if (file.open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text)) {
        QTextStream out(&file);
        for (const QString &l : lines) out << l << "\n";
        file.close();
    }
}

// Wczytanie ulubionych z pliku
QStringList MainWindow::loadFavorites() const {
    QStringList list;
    QFile file(FAVORITES_FILE);
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        while (!in.atEnd()) list << in.readLine();
        file.close();
    }
    return list;
}

// Wyświetlenie okna z listą ulubionych
void MainWindow::onShowFavoritesClicked() {
    QDialog dlg(this);
    dlg.setWindowTitle("Ulubione");
    QVBoxLayout *vLayout = new QVBoxLayout(&dlg);
    QListWidget *listWidget = new QListWidget(&dlg);
    listWidget->addItems(loadFavorites());
    connect(listWidget, &QListWidget::itemDoubleClicked,
            this, &MainWindow::onFavoriteItemDoubleClicked);
    vLayout->addWidget(listWidget);

    QPushButton *closeFav = new QPushButton("Zamknij", &dlg);
    connect(closeFav, &QPushButton::clicked, &dlg, &QDialog::accept);
    vLayout->addWidget(closeFav);
    dlg.exec();
}

// Obsługa kliknięcia na ulubione zdjęcie – otwiera je
void MainWindow::onFavoriteItemDoubleClicked(QListWidgetItem *item) {
    const QString entry = item->text();
    const QString date = entry.section(' ', 0, 0); // wyciągnięcie daty z tekstu
    onDateSelected(QDate::fromString(date, "yyyy-MM-dd")); // otwarcie zdjęcia
}

// Zamknięcie aplikacji
void MainWindow::onCloseClicked() {
    close();
}
