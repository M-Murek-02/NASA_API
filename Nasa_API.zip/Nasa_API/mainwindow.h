#ifndef MAINWINDOW_H
#define MAINWINDOW_H

// Zapobiega wielokrotnemu dołączeniu pliku nagłówkowego

// Qt – podstawowe komponenty do tworzenia GUI
#include <QWidget>
#include <QLabel>
#include <QTextEdit>
#include <QNetworkAccessManager>
#include <QDate>
#include <QPushButton>
#include <QCalendarWidget>
#include <QDialog>
#include <QStringList>

// Deklaracje klas używanych w sygnałach/slotach, których nie musimy jeszcze implementować
class QNetworkReply;
class QListWidget;
class QListWidgetItem;

// Deklaracja klasy głównego okna aplikacji
class MainWindow : public QWidget {
    Q_OBJECT  // Makro Qt wymagane do obsługi sygnałów i slotów

public:
    // Konstruktor klasy, opcjonalnie z rodzicem (nullptr oznacza brak rodzica – główne okno)
    explicit MainWindow(QWidget *parent = nullptr);

    // Destruktor klasy
    ~MainWindow() override;

private slots:
    // Slot do pobierania zdjęcia dnia z NASA APOD
    void fetchAPOD();

    // Slot obsługujący kliknięcie przycisku "Kalendarz"
    void onCalendarClicked();

    // Slot obsługujący wybór daty z kalendarza
    void onDateSelected(const QDate &date);

    // Slot obsługujący kliknięcie przycisku "Zamknij program"
    void onCloseClicked();

    // Slot do dodania/usupełnienia zdjęcia jako ulubionego
    void onFavoriteClicked();

    // Slot obsługujący kliknięcie przycisku "Ulubione"
    void onShowFavoritesClicked();

    // Slot obsługujący podwójne kliknięcie na liście ulubionych
    void onFavoriteItemDoubleClicked(QListWidgetItem *item);

private:
    // Zapisuje zdjęcie do pliku ulubionych
    void saveFavorite(const QString &date, const QString &title);

    // Usuwa zdjęcie z listy ulubionych
    void removeFavorite(const QString &date, const QString &title);

    // Ładuje wszystkie ulubione zdjęcia z pliku tekstowego
    QStringList loadFavorites() const;

    // Aktualizuje wygląd ikony gwiazdki (czy jest aktywna/ulubiona)
    void updateStarIcon();

    // ===== Pola prywatne klasy =====

    // Obiekt do wykonywania żądań HTTP
    QNetworkAccessManager *networkManager;

    // Etykieta z tytułem zdjęcia
    QLabel *titleLabel;

    // Etykieta z datą zdjęcia
    QLabel *dateLabel;

    // Etykieta z obrazem APOD (QPixmap wyświetlany tutaj)
    QLabel *imageLabel;

    // Pole tekstowe z opisem zdjęcia
    QTextEdit *explanationText;

    // Przycisk do pobrania aktualnego zdjęcia dnia
    QPushButton *fetchButton;

    // Przycisk otwierający kalendarz wyboru daty
    QPushButton *calendarButton;

    // Przycisk do zamykania aplikacji
    QPushButton *closeButton;

    // Przycisk "gwiazdki" do dodawania/odpinania ulubionych
    QPushButton *starButton;

    // Przycisk otwierający listę ulubionych zdjęć
    QPushButton *favoritesButton;

    // Wskaźnik na okno dialogowe z kalendarzem
    QDialog *calendarDialog;

    // Widżet kalendarza używany w oknie wyboru daty
    QCalendarWidget *calendarWidget;

    // Aktualnie wybrana data (np. z kalendarza lub z API)
    QString currentDate;

    // Aktualny tytuł zdjęcia (potrzebny do ulubionych)
    QString currentTitle;

    // Czy aktualne zdjęcie jest w ulubionych
    bool isFavorite = false;
};

#endif // MAINWINDOW_H
